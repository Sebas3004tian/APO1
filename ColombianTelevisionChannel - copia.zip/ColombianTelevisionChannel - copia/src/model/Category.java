package model;

public enum Category {
	ROMANTICA, ACCION, SUSPENSO, TERROR,COMEDIA

}