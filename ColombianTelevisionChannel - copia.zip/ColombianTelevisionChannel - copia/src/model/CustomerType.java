package model;

public enum CustomerType {
	NORMAL, PLATINUM, GOLD, DIAMOND

}