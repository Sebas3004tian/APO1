package model;

public class BlackSnail {
	

	private int nit;
	private String address;
	private String website;
	
	private Subscriber [] subscribers;
	private int Subscriber []=new int [50];
	
	public BlackSnail(int nit, String address, String website) {
		this.nit = nit;
		this.address = address;
		this.website = website;
		subscribers=new Subscriber[50];
		
	}
	public int getNit() {
		return nit;
	}

	public void setNit(int nit) {
		this.nit = nit;
	}
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}
	public boolean verifyID(int id){
		boolean out=false;
		for(int x=0;x<50;x++){
			if(subscribers[x]!=null){
				if(id==subscribers[x].getID()){
					return true;
				}
			}
			
		}
		return out;
		
	}
	public boolean SpaceForMoreSubscribers(){
		boolean thereIsNot=false;
		int position=-1;
		for(int x=0;x<50;x++){
			if(x==49){
				if(subscribers[49]!=null){
					thereIsNot=true;
				}
			}
			if(subscribers[x]==null){
				position=x;
				x=50;
			}
			
			
		}
		if(position==-1){
			thereIsNot=true;
		}
		return thereIsNot;
		
	}
	/*public String AllSuscriptor(){
		String allSuscriptorRegistered="";

		for(int x=0; x<50; x++ ){

			if(subscribers[x]!=null){
				allSuscriptorRegistered+="SUSCRIPTOR "+(x+1)+ " \n";
				allSuscriptorRegistered+=subscribers[x].toString();
				allSuscriptorRegistered+="\n";
			}
			
		}
		
		return allSuscriptorRegistered;
	}*/
	public void addSubscriber(int id,String fullName,int age,int hoursWillingConsume,int clientType){
		boolean saved=false;
		int savedPosition=-1;
		

		for(int x=0;x<50;x++){
			if(subscribers[x]==null){
				
				subscribers[x] = new Subscriber(id, fullName, age, hoursWillingConsume);
				if(clientType==1){
					subscribers[x].setType(CustomerType.NORMAL);
				}
				if(clientType==2){
					subscribers[x].setType(CustomerType.PLATINUM);
				}
				if(clientType==3){
					subscribers[x].setType(CustomerType.GOLD);
				}
				if(clientType==4){
					subscribers[x].setType(CustomerType.DIAMOND);
				}
				subscribers[x].setStatus(Status.ACTIVE);
				saved=true;
			}
			if(saved){
				
				savedPosition=x;
				x=50;
			}
			
			
		}
		
		

	}
	public boolean numDeactivateExists(int numberDisable){
		boolean yesExists=false;
		if(subscribers[numberDisable-1]!=null){
			yesExists=true;
		}

		return yesExists;
	}
	public void disableSubscriberNumber(int numberDisable){
		subscribers[numberDisable-1].setStatus(Status.INACTIVE);
		subscribers[numberDisable-1].setType(CustomerType.NORMAL);
	}
	public boolean idDeactivateExists(int idForDisable){
		boolean yesExists=false;
		int positionSubscriberDeactivate=-1;
		for(int x=0;x<50;x++){
			if(subscribers[x]!=null){
				if(idForDisable==subscribers[x].getID()){
					positionSubscriberDeactivate=x;
				}
			}
			
		}
		if(positionSubscriberDeactivate!=-1){
			yesExists=true;
		}
		return yesExists;
	}

	public void deactivateSubscriber(int idForDisable){
		
		int positionSubscriberDeactivate=-1;
		for(int x=0;x<50;x++){
			if(subscribers[x]!=null){
				if(idForDisable==subscribers[x].getID()){
					positionSubscriberDeactivate=x;
				}
			}
			
		}
		if(positionSubscriberDeactivate!=-1){
			subscribers[positionSubscriberDeactivate].setStatus(Status.INACTIVE);
			subscribers[positionSubscriberDeactivate].setType(CustomerType.NORMAL);
			
		}
	}
	public String infoTOTALAct(){
		
		int numActiveSubscribers=0;
		for(int x=0;x<50;x++){
			if(subscribers[x]!=null){
				if(subscribers[x].getStatus()==Status.ACTIVE){
					numActiveSubscribers+=1;
				}
			}
			
		}
		return "-The total number of active subscribers is:  "+numActiveSubscribers+"\n";
	}
	public String infoNORMAL(){
		
		int ActiveNORMAL=0;
		for(int x=0;x<50;x++){
			if(subscribers[x]!=null){
				if(subscribers[x].getStatus()==Status.ACTIVE){
					if(subscribers[x].getType()==CustomerType.NORMAL){
						ActiveNORMAL+=1;
					}
				}
			}
			
		}
		return "-The number of active and NORMAL subscribers: "+ActiveNORMAL+"\n";
	}
	public String infoPLATINUM(){
		
		int ActivePLATINUM=0;
		for(int x=0;x<50;x++){
			if(subscribers[x]!=null){
				if(subscribers[x].getStatus()==Status.ACTIVE){
					if(subscribers[x].getType()==CustomerType.PLATINUM){
						ActivePLATINUM+=1;
					}
				}
			}
			
		}
		return "-The number of active and PLATINUM subscribers:"+ActivePLATINUM+"\n";
	}
	public String infoGOLD(){
		
		int ActiveGOLD=0;
		for(int x=0;x<50;x++){
			if(subscribers[x]!=null){
				if(subscribers[x].getStatus()==Status.ACTIVE){
					if(subscribers[x].getType()==CustomerType.GOLD){
						ActiveGOLD+=1;
					}
				}
			}
			
		}
		return "-The number of active and GOLD subscribers:"+ActiveGOLD+"\n";
	}
	public String infoDIAMOND(){
		
		int ActiveDIAMOND=0;
		for(int x=0;x<50;x++){
			if(subscribers[x]!=null){
				if(subscribers[x].getStatus()==Status.ACTIVE){
					if(subscribers[x].getType()==CustomerType.DIAMOND){
						ActiveDIAMOND+=1;
					}
				}
			}
			
		}
		return "-The number of active and DIAMOND subscribers:"+ActiveDIAMOND+"\n";
	}
	public String subscriberMayorWillConsume(){
		int numSubscriber=0;
		int biggerNumber=0;
		for(int x=0;x<50;x++){
			if(subscribers[x]!=null){
				if(subscribers[x].getAge()<18){
					if(subscribers[x].getStatus()==Status.ACTIVE){
						if(subscribers[x].getHoursWillingConsume()>biggerNumber){ 
							biggerNumber = subscribers[x].getHoursWillingConsume();
							numSubscriber=x;
						}
					}
				}
			}
		}
		return"The youngest subscriber of age who has the highest number of hours willing to consume is:"+subscribers[numSubscriber].toString();
		
	}
	

}