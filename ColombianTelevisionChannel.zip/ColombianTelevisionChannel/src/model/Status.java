package model;

public enum Status {
	ACTIVE, INACTIVE

}
