package model;

public enum Processor {
    AMD, INTEL;
}
