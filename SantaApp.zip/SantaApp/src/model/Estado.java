package model;


public enum Estado {
	BUENO, MALO

}